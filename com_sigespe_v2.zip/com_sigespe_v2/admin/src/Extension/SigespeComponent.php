<?php
namespace Sigespe\Component\Sigespe\Administrator\Extension;

defined('JPATH_PLATFORM') or die;

use Joomla\CMS\Extension\MVCComponent;

class SigespeComponent extends MVCComponent
{
    // Esta classe é necessária para o Joomla reconhecer o componente
}